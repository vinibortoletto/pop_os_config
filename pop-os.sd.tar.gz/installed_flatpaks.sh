flatpak install --system com.stremio.Stremio -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
