flatpak install --user com.discordapp.Discord -y
flatpak install --user com.getpostman.Postman -y
flatpak install --user com.jetbrains.IntelliJ-IDEA-Community -y
flatpak install --user com.jetbrains.PhpStorm -y
flatpak install --user io.beekeeperstudio.Studio -y
flatpak install --user io.github.shiftey.Desktop -y
flatpak install --user org.godotengine.Godot -y
flatpak install --user org.qbittorrent.qBittorrent -y
